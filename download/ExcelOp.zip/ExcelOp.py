import os
from datetime import datetime, date

import xlrd
import prettytable
import xlwt
import xlsxwriter

# out目录
outDir = r'.\\output\\'
# 文件名
file_name = outDir + "测试Excel读写.xlsx"

sheet_name = '账号信息'
row0_2 = ["媒体", "产品", "系统", "账号"]
simple_end_col = ["消耗（元）", "折前"]
colum0 = ["猎豹", "Wifi"]
liebao_accounts = [{"account": "liebao1", "app": "抖音", "system": "android", "spend": "23.11"},
                   {"account": "liebao2", "app": "抖音", "system": "ios", "spend": "20.12"},
                   {"account": "liebao3", "app": "红果免费小说", "system": "ios", "spend": "99.02"},
                   {"account": "liebao4", "app": "抖音极速版", "system": "android", "spend": "155.8"}]
wifi_accounts = [{"account": "wifi1", "app": "今日头条lite版", "system": "android", "spend": "50.99"},
                 {"account": "wifi2", "app": "今日头条lite版", "system": "ios", "spend": "30.18"},
                 {"account": "wifi3", "app": "火山小视频", "system": "ios", "spend": "99.05"},
                 {"account": "wifi4", "app": "今日头条", "system": "android", "spend": "200.8"},
                 {"account": "wifi5", "app": "今日头条", "system": "ios", "spend": "50.2"},
                 {"account": "wifi6", "app": "抖音极速版", "system": "android", "spend": "544.1"}]

style_sheet_name = '带样式'


def get_style(simple_ceil=False, num_format=False, bold=False):
    '''
    设置表格样式
    :param simple_ceil: 是否为 普通单元格，默认为非普通单元格
    :param num_format: 是否为需要格式化的数字单元格
    :param bold: 是否需要加粗
    :return:
    '''
    style = xlwt.XFStyle()
    if not simple_ceil:
        # 字体
        font = xlwt.Font()
        font.name = "宋体"
        font.bold = bold
        font.underline = False
        font.italic = False
        font.colour_index = 0
        font.height = 200  # 200为10号字体
        style.font = font

        # 单元格居中
        align = xlwt.Alignment()
        align.horz = xlwt.Alignment.HORZ_CENTER  # 水平方向
        align.vert = xlwt.Alignment.VERT_CENTER  # 竖直方向
        style.alignment = align

        # 背景色
        pattern = xlwt.Pattern()
        pattern.pattern = xlwt.Pattern.SOLID_PATTERN
        pattern.pattern_fore_colour = xlwt.Style.colour_map['pale_blue']  # 设置单元格背景色为黄色
        style.pattern = pattern

    # 边框
    border = xlwt.Borders()  # 给单元格加框线
    border.left = xlwt.Borders.THIN  # 左
    border.top = xlwt.Borders.THIN  # 上
    border.right = xlwt.Borders.THIN  # 右
    border.bottom = xlwt.Borders.THIN  # 下
    border.left_colour = 0x40  # 边框线颜色
    border.right_colour = 0x40
    border.top_colour = 0x40
    border.bottom_colour = 0x40
    style.borders = border

    # 数字格式化
    if num_format:
        style.num_format_str = 'M/D/YY'  # 选项: D-MMM-YY, D-MMM-YY, D-MMM, MMM-YY, h:mm, h:mm:ss, h:mm, h:mm:ss, M/D/YY h:mm, mm:ss, [h]:mm:ss, mm:ss.0
    return style


def xlwt_excel():
    '''
    表格写入
    :return:
    '''
    # 获得可写入的workbook对象
    wk = xlwt.Workbook()
    # 增加一个sheet 并且单元格可重写
    sheet1 = wk.add_sheet(sheet_name, cell_overwrite_ok=True)

    # 合并的行：写入合并的第一、二行
    for i in range(0, len(row0_2)):
        sheet1.write_merge(0, 1, i, i, row0_2[i], get_style())

    # 写入单个最后一列的第一、二行：分开的两行消耗（元） 折前
    sheet1.write(0, len(row0_2), simple_end_col[0], get_style())
    sheet1.write(1, len(row0_2), simple_end_col[1], get_style())

    # 合并的行：写第一列
    sheet1.write_merge(2, len(liebao_accounts) + 1, 0, 0, colum0[0], get_style())
    sheet1.write_merge(2 + len(liebao_accounts), len(liebao_accounts) + len(wifi_accounts) + 1, 0, 0, colum0[1],
                       get_style())

    # 写入单个单元格：写猎豹数据：
    for index in range(0, len(liebao_accounts)):
        sheet1.write(2 + index, 1, liebao_accounts[index]['app'], get_style(True))
        sheet1.write(2 + index, 2, liebao_accounts[index]['system'], get_style(True))
        sheet1.write(2 + index, 3, liebao_accounts[index]['account'], get_style(True))
        sheet1.write(2 + index, 4, float(liebao_accounts[index]['spend']), get_style(True))

    # 写入单个单元格：写入wifi数据
    for index in range(0, len(wifi_accounts)):
        sheet1.write(2 + len(liebao_accounts) + index, 1, wifi_accounts[index]['app'], get_style(True))
        sheet1.write(2 + len(liebao_accounts) + index, 2, wifi_accounts[index]['system'], get_style(True))
        sheet1.write(2 + len(liebao_accounts) + index, 3, wifi_accounts[index]['account'], get_style(True))
        sheet1.write(2 + len(liebao_accounts) + index, 4, float(wifi_accounts[index]['spend']), get_style(True))

    # 写入数字格式化
    sheet1.write_merge(2 + len(liebao_accounts) + len(wifi_accounts), 2 + len(liebao_accounts) + len(wifi_accounts), 0,
                       1, datetime.now(), get_style(num_format=True))

    # 写入合并列：合计
    sheet1.write_merge(2 + len(liebao_accounts) + len(wifi_accounts), 2 + len(liebao_accounts) + len(wifi_accounts), 2,
                       3, "合计", get_style())
    # 写入公式：求和消耗总和
    sheet1.write(2 + len(liebao_accounts) + len(wifi_accounts), 4,
                 xlwt.Formula("SUM(E3:E%d)" % (3 + len(liebao_accounts) + len(wifi_accounts) - 1)), get_style())

    # 写入超链接
    sheet1.write_merge(3 + len(liebao_accounts) + len(wifi_accounts), 3 + len(liebao_accounts) + len(wifi_accounts), 0,
                       4, xlwt.Formula('HYPERLINK("https://sunflowercoder.com/";"更多好文 点击查看我的博客")'),
                       get_style(bold=True))

    # 修改列宽度
    for i in range(0, len(row0_2) + 1):
        sheet1.col(i).width = 150 * 30  # 定义列宽
    sheet1.col(0).width = 50 * 30  # 定义列宽
    sheet1.col(2).width = 200 * 30  # 定义列宽

    # 保存到文件
    wk.save(file_name)


def xlrd_excel():
    '''
    表格读取
    :return:
    '''
    # 打开文件
    wb = xlrd.open_workbook(filename=file_name, formatting_info=True)
    # 获取所有表格名字
    print("所有的表格名：", wb.sheet_names())
    # 通过索引获取表格
    sheet1 = wb.sheet_by_index(0)
    # 通过名字获取表格
    # sheet2 = wb.sheet_by_name(sheet_name)
    # 输出表格的名字，行数和列数
    print("第一个表格名：", sheet1.name, "   行数：", sheet1.nrows, "  列数：", sheet1.ncols)

    # 获取行、列的内容
    rows = sheet1.row_values(0)  # 获取第一行的内容
    cols = sheet1.col_values(0)  # 获取第一列内容
    print(rows)
    print(cols)

    # 获取单元格内容 三种方式
    print(sheet1.cell(0, 4).value)
    print(sheet1.cell_value(0, 4))
    print(sheet1.row(0)[4].value)

    # 输出合并表格的内容：注意 xlrd.open_workbook()时，必须formatting_info=True，否则merged_cells返回空
    merged_cells = sheet1.merged_cells
    print("合并的单元格：", merged_cells)
    for item in merged_cells:
        # 合并的单元格为元组形式 如(12, 13, 0, 2) 为(开始的行标，结束的行标，开始的列标，结束的列标) 取值为（开始的行标，开始的列标）即可
        print("合并的单元格", item, "值为：", sheet1.cell_value(item[0], item[2]))

    # Python读取Excel中单元格的内容返回的有5种类型，ctype分别为 :  0 empty，1 string，2 number， 3 date，4 boolean，5 error
    # 输出日期格式
    if sheet1.cell_type(12, 0) == 3:
        date_value = xlrd.xldate_as_tuple(sheet1.cell_value(12, 0), wb.datemode)
        print("日期为：", date_value, )
        print("日期为（格式为2019-09-17）：", date(*date_value[:3]))
        print("日期为（格式为2019/09/17）：", date(*date_value[:3]).strftime('%Y/%m/%d'))

    # 输出超链接

    # 利用prettytable以表格形式打印输出
    # tb = prettytable.PrettyTable()
    # tb.field_names = sheet1.row_values(0)
    #
    # for i in range(1, sheet1.nrows):
    #     tb.add_row(sheet1.row_values(i))
    # print(tb)


if __name__ == "__main__":
    if not os.path.exists(outDir):
        os.makedirs(outDir)

    # 写入
    xlwt_excel()
    # 读取
    xlrd_excel()
